package helloworld.app

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
